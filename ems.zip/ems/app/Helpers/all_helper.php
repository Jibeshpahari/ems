<?php

if (!function_exists('truncate_words')) {
    function truncate_words(string $text, int $limit = 20): string
    {
        $words = explode(' ', $text);
        if (count($words) > $limit) {
            $text = implode(' ', array_slice($words, 0, $limit)) . '...';
        }
        return $text;
    }
}
