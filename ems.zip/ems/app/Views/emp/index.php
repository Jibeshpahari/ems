<?= $this->extend('layout/app') ?>

<?= $this->section('title') ?>
Dashboard
<?= $this->endSection() ?>

<?= $this->section('css') ?>
<style>
    .profile-img {
        width: 60px;
        height: 60px;
        object-fit: cover;
        border-radius: 50%;
    }

    .image-preview {
        width: 100px;
        height: 100px;
        border: 2px dashed #dee2e6;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        overflow: hidden;
        cursor: pointer;
    }

    .image-preview img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .image-preview-text {
        color: #59636bff;
        text-align: center;
        padding: 10px;
    }

    .tooltip-inner {
        line-height: 1.6;
        padding: 50px 50px;
        max-width: 300px;
        white-space: normal;
        font-size: 14px;
        background-color: red;
    }

    .fluc::first-letter {
        text-transform: uppercase;
    }
</style>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<div class="container ">
    <div class="mt-5 text-end mb-2">
        <h5>Hi, <strong><?= session()->get('name') ?></strong></h5>
    </div>
    <div class="card p-3">
        <?php if (isset($validation)): ?>
            <div class="alert alert-danger">
                <ul class="m-0">
                    <?php foreach ($validation->getErrors() as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                <?= esc($success) ?>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Employee List</h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addUserModal">Add Employee</button>
        </div>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th class="text-center">Picture</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Salary</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($emps) && is_array($emps)): ?>
                    <?php foreach ($emps as $emp): ?>
                        <tr>
                            <td class="text-center">
                                <img src="<?= base_url('uploads/' . esc($emp['picture'])) ?>" alt="Employee Picture" class="img-thumbnail profile-img">
                            </td>
                            <td><?= esc($emp['name']) ?></td>
                            <td><?= esc($emp['designation']) ?></td>
                            <td><?= esc($emp['salary']) ?></td>
                            <td>
                                <span
                                    data-bs-toggle="tooltip"
                                    data-bs-placement="top"
                                    title="<?= esc($emp['address']) ?>">
                                    <?= esc(truncate_words($emp['address'], 10)) ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-warning editBtn" data-id="<?= $emp['id'] ?>">
                                    <span class="btn-text">Edit</span>
                                    <span class="spinner-border spinner-border-sm d-none" role="status"></span>
                                </button>

                                <button class="btn btn-sm btn-danger deleteBtn" data-id="<?= $emp['id'] ?>">
                                    Delete
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No Employees Found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?= $this->endSection() ?>

        <?= $this->section('model') ?>
        <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="addEmpForm" action="" method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-12 mb-3">
                                    <label class="form-label d-block text-center">Profile Picture</label>
                                    <div class="image-preview" id="imagePreview">
                                        <div class="image-preview-text">
                                            Click to upload
                                        </div>
                                    </div>
                                    <input type="file" class="form-control d-none" id="picture" name="picture" accept="image/*">
                                    <div class="invalid-feedback text-capitalize fluc" id="pictureError"></div>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label for="name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter name" required>
                                    <div class="invalid-feedback" id="nameError"></div>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label for="designation" class="form-label">Designation</label>
                                    <input type="text" class="form-control" id="designation" name="designation" placeholder="Enter designation" required>
                                    <div class="invalid-feedback" id="designationError"></div>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label for="salary" class="form-label">Salary</label>
                                    <input type="number" class="form-control" id="salary" name="salary" placeholder="Enter salary" required>
                                    <div class="invalid-feedback" id="salaryError"></div>
                                </div>

                                <div class="col-md-12 mb-3">
                                    <label for="phone" class="form-label">Address</label>
                                    <textarea name="address" id="address" class="form-control" placeholder="Enter Address"></textarea>
                                    <div class="invalid-feedback" id="addressError"></div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">Submit</button>
                        <button type="submit" class="btn btn-primary d-none" id="updateBtn">Update</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?= $this->endSection() ?>

    <?= $this->section('js') ?>
    <script>
        $(document).ready(function() {
            let id = null;
            $('#imagePreview').on('click', function() {
                $('#picture').trigger('click');
            });

            $('#picture').on('change', function() {
                const file = this.files[0];
                if (!file) return;
                $('#imagePreview').empty();
                $('#imagePreview')
                    .css({
                        'background-image': `url(${URL.createObjectURL(file)})`,
                        'background-size': 'cover',
                        'background-position': 'center',
                        'border': 'none'
                    });
            });

            $('#addUserModal').on('hidden.bs.modal', function() {
                $('#addEmpForm')[0].reset();
                $('#imagePreview').html('<div class="image-preview-text">Click to upload</div>')
                    .css({
                        'background-image': 'none',
                        'border': '2px dashed #dee2e6'
                    });
                $('#submitBtn').removeClass('d-none');
                $('#updateBtn').addClass('d-none');
                $('#addUserModalLabel').text('Add User');
                $('.form-control').removeClass('is-invalid');
                $('.invalid-feedback').text('');
                id = null;
            });

            $('#submitBtn').on('click', function() {
                var formData = new FormData($('#addEmpForm')[0]);
                $(this).prop('disabled', true);
                $.ajax({
                    url: '<?= base_url('employees/store') ?>',
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'error') {
                            $.each(response.errors, function(field, message) {
                                if (field === 'picture') {
                                    $('#imagePreview').css('border', '2px solid #dc3545');
                                }
                                $('#' + field).addClass('is-invalid');
                                $('#' + field + 'Error').text(message);
                            });
                        } else if (response.status === 'success') {
                            location.reload();
                        }
                    },
                    complete: function() {
                        $('#submitBtn').prop('disabled', false);
                    }
                });
            });

            $('.editBtn').on('click', function() {
                const btn = $(this);
                id = $(this).data('id');
                $('#updateBtn').removeClass('d-none');
                $('#submitBtn').addClass('d-none');
                $('.form-control').removeClass('is-invalid');
                $('.invalid-feedback').text('');
                btn.prop('disabled', true);
                btn.find('.btn-text').addClass('d-none');
                btn.find('.spinner-border').removeClass('d-none');
                var formData = new FormData($('#addEmpForm')[0]);
                $.ajax({
                    url: "<?= site_url('employees/edit') ?>/" + id,
                    type: "GET",
                    dataType: "json",

                    success: function(response) {
                        if (response.status === 'success') {
                            const emp = response.data;
                            $('#addUserModalLabel').text('Edit Employee');
                            $('#addEmpForm').attr('action', "<?= site_url('employees/update') ?>/" + id);
                            $('#empId').val(emp.id);
                            $('#name').val(emp.name);
                            $('#designation').val(emp.designation);
                            $('#salary').val(emp.salary);
                            $('#address').val(emp.address);
                            if (emp.picture) {
                                $('#imagePreview').html(`
                                    <img src="<?= base_url('uploads') ?>/${emp.picture}"
                                        class="img-fluid rounded"
                                        style="max-height:150px;">
                                `);
                            } else {
                                $('#imagePreview').html('<div class="image-preview-text">Click to upload</div>');
                            }
                            $('#addUserModal').modal('show');
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function() {
                        alert('Failed to load data');
                    },
                    complete: function() {
                        btn.prop('disabled', false);
                        btn.find('.btn-text').removeClass('d-none');
                        btn.find('.spinner-border').addClass('d-none');
                    }
                });
            });

            $('#updateBtn').on('click', function() {
                $(this).prop('disabled', true);
                var formData = new FormData($('#addEmpForm')[0]);
                $.ajax({
                    url: "<?= site_url('employees/update') ?>/" + id,
                    type: 'POST',
                    data: formData,
                    contentType: false,
                    processData: false,
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'error') {
                            $.each(response.errors, function(field, message) {
                                $('#' + field).addClass('is-invalid');
                                $('#' + field + 'Error').text(message);
                            });
                        } else if (response.status === 'success') {
                            location.reload();
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Something went wrong: ' + error);
                    },
                    complete: function() {
                        $('#updateBtn').prop('disabled', false);
                    }

                });
            });

            $('.deleteBtn').on('click', function() {
                const id = $(this).data('id');
                if (confirm('Are you sure you want to delete this employee?')) {
                    window.location.href = "<?= site_url('employees/delete') ?>/" + id;
                }
            });
        });
    </script>

    <?= $this->endSection() ?>