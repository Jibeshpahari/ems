<?php

namespace App\Controllers;

use App\Models\LoginModel;

class Auth extends BaseController
{
    public function login()
    {
        return view('auth/login');
    }

    public function loginPost()
    {
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $validation = \Config\Services::validation();

        if (empty($username)) {
            $validation->setError('username', 'Username is required');
        }

        if (empty($password)) {
            $validation->setError('password', 'Password is required');
        }

        if ($validation->getErrors()) {
            return redirect()->back()->with('validation', $validation->getErrors());
        }

        $loginModel = new LoginModel();
        $user = $loginModel->where('user_name', $username)->first();

        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Invalid login');
        }

        session()->set([
            'user_id' => $user['id'],
            'logged_in' => true,
            'name' => $user['name']
        ]);

        return redirect()->to('/employees');
    }


    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
