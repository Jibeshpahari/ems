<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\EmpModel;
use CodeIgniter\HTTP\ResponseInterface;

class Emp extends BaseController
{
    public function index()
    {
        // Load the helper for truncating words
        helper('all');
        $model = new EmpModel();
        $emps = $model->findAll();
        return view('emp/index', ['emps' => $emps]);
    }

    public function create()
    {
        return view('emp/add');
    }

    public function store()
    {
        $validation = \Config\Services::validation();

        $validation->setRules([
            'name' => 'required|min_length[3]|max_length[100]',
            'designation' => 'required|min_length[2]|max_length[100]',
            'salary' => 'required|decimal',
            'address' => 'required|min_length[5]',
            'picture' => 'uploaded[picture]|is_image[picture]|max_size[picture,2048]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'status' => 'error',
                'errors' => $validation->getErrors()
            ]);
        }

        $picture = $this->request->getFile('picture');
        if ($picture && $picture->isValid() && !$picture->hasMoved()) {
            $newName = $picture->getRandomName();
            $picture->move(ROOTPATH . 'public/uploads', $newName);
        } else {
            $newName = null;
        }
        
        $model = new EmpModel();
        $model->save([
            'name' => $this->request->getPost('name'),
            'designation' => $this->request->getPost('designation'),
            'salary' => $this->request->getPost('salary'),
            'address' => $this->request->getPost('address'),
            'picture' => $newName,
        ]);

        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Employee added successfully.'
        ]);
    }


    public function edit($id)
    {
        $model = new EmpModel();
        $emp = $model->find($id);

        if (!$emp) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Employee not found'
            ]);
        }

        return $this->response->setJSON([
            'status' => 'success',
            'data' => $emp
        ]);
    }

    public function update($id)
    {
        
        $model = new EmpModel();
        $emp = $model->find($id);
        if (!$emp) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Employee not found'
            ]);
        }
        $validation = \Config\Services::validation();
        $validation->setRules([
            'name' => 'required|min_length[3]|max_length[100]',
            'designation' => 'required|min_length[2]|max_length[100]',
            'salary' => 'required|decimal',
            'address' => 'required|min_length[5]',
            'picture' => 'is_image[picture]|max_size[picture,2048]'
        ]);
        if (!$validation->withRequest($this->request)->run()) {
            return $this->response->setJSON([
                'status' => 'error',
                'errors' => $validation->getErrors()
            ]);
        }
        $data = [
            'name' => $this->request->getPost('name'),
            'designation' => $this->request->getPost('designation'),
            'salary' => $this->request->getPost('salary'),
            'address' => $this->request->getPost('address'),
        ];
        $picture = $this->request->getFile('picture');
        if ($picture && $picture->isValid() && !$picture->hasMoved()) {
            // Delete old picture if exists
            if ($emp['picture']) {
                $oldPicturePath = ROOTPATH . 'public/uploads/' . $emp['picture'];
                if (file_exists($oldPicturePath)) {
                    unlink($oldPicturePath);
                }
            }
            $newName = $picture->getRandomName();
            $picture->move(ROOTPATH . 'public/uploads', $newName);
            $data['picture'] = $newName;
        }
        $model->update($id, $data);
        return $this->response->setJSON([
            'status' => 'success',
            'message' => 'Employee updated successfully.'
        ]);
    }
    public function delete($id)
    {
        $model = new EmpModel();
        $emp = $model->find($id);
        if (!$emp) {
            return redirect()->to('/employees')->with('error', 'Employee not found');
        }
        // Delete picture if exists
        if ($emp['picture']) {
            $oldPicturePath = ROOTPATH . 'public/uploads/' . $emp['picture'];
            if (file_exists($oldPicturePath)) {
                unlink($oldPicturePath);
            }
        }
        $model->delete($id);
        return redirect()->to('/employees')->with('success', 'Employee deleted successfully.');
    }
}
