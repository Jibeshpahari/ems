<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// $routes->get('/', 'Emp::index');
$routes->get('/', function () {
    return redirect()->to('/employees');
});

// $routes->get('test-hash/(:any)', function ($text) {
//     $hashed = password_hash($text, PASSWORD_DEFAULT);
//     return "Original: $text <br> Hashed: $hashed";
// });

$routes->get('/login', 'Auth::login');
$routes->post('/login', 'Auth::loginPost');
$routes->get('/logout', 'Auth::logout');

$routes->group('employees', ['filter' => 'auth'], function ($routes) {
    $routes->get('/', 'Emp::index');
    $routes->get('create', 'Emp::create');
    $routes->post('store', 'Emp::store');
    $routes->get('edit/(:num)', 'Emp::edit/$1');
    $routes->post('update/(:num)', 'Emp::update/$1');
    $routes->get('delete/(:num)', 'Emp::delete/$1');
});
