<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class LoginDetailSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'user_name'       => 'admin',
                'password'   => password_hash('12345678', PASSWORD_DEFAULT),
                'name'      => 'John Doe',
                'created_at' => date('Y-m-d H:i:s'),
            ],
        ];

        $this->db->table('login_details')->insertBatch($data);
    }
}
